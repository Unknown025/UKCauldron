package org.bukkit.entity;

/**
 * A crystal that heals nearby EnderDragons
 */
public interface EnderCrystal extends Entity {
}