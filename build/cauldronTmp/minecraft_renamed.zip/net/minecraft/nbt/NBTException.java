package net.minecraft.nbt;

public class NBTException extends Exception
{
    private static final String __OBFID = "CL_00001231";

    public NBTException(String p_i45136_1_)
    {
        super(p_i45136_1_);
    }
}