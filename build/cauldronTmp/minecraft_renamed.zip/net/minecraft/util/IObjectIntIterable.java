package net.minecraft.util;

public interface IObjectIntIterable extends Iterable
{
}