package net.minecraft.util;

public class Facing
{
    public static final int[] field_71588_a = new int[] {1, 0, 3, 2, 5, 4};
    public static final int[] field_71586_b = new int[] {0, 0, 0, 0, -1, 1};
    public static final int[] field_71587_c = new int[] { -1, 1, 0, 0, 0, 0};
    public static final int[] field_71585_d = new int[] {0, 0, -1, 1, 0, 0};
    public static final String[] field_82374_e = new String[] {"DOWN", "UP", "NORTH", "SOUTH", "WEST", "EAST"};
    private static final String __OBFID = "CL_00001532";
}