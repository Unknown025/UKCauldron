package net.minecraft.util;

public class TupleIntJsonSerializable
{
    private int field_151192_a;
    private IJsonSerializable field_151191_b;
    private static final String __OBFID = "CL_00001478";

    public int func_151189_a()
    {
        return this.field_151192_a;
    }

    public void func_151188_a(int p_151188_1_)
    {
        this.field_151192_a = p_151188_1_;
    }

    public IJsonSerializable func_151187_b()
    {
        return this.field_151191_b;
    }

    public void func_151190_a(IJsonSerializable p_151190_1_)
    {
        this.field_151191_b = p_151190_1_;
    }
}