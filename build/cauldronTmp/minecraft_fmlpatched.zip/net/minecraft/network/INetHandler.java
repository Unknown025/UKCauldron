package net.minecraft.network;

import net.minecraft.util.IChatComponent;

public interface INetHandler
{
    void func_147231_a(IChatComponent p_147231_1_);

    void func_147232_a(EnumConnectionState p_147232_1_, EnumConnectionState p_147232_2_);

    void func_147233_a();
}