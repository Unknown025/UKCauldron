package net.minecraft.command;

public interface IAdminCommand
{
    void func_152372_a(ICommandSender p_152372_1_, ICommand p_152372_2_, int p_152372_3_, String p_152372_4_, Object ... p_152372_5_);
}