package cpw.mods.fml.common.registry;

public class ExistingSubstitutionException extends Exception {
    public ExistingSubstitutionException(String fromName, Object toReplace) {
    }

    private static final long serialVersionUID = 1L;

}
